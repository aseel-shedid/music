/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/

public class Main
{
    // Main method to test the functionality
    public static void main(String[] args) {
        Store store = new Store();

        Item item1 = new Item("The Dark Side of the Moon", "Pink Floyd", 25.99);
        Item item2 = new Item("Thriller", "Michael Jackson", 19.99);

        store.addItem(item1);
        store.addItem(item2);

        store.displayInventory();

        store.removeItem("The Dark Side of the Moon");
        store.displayInventory();
    }
}