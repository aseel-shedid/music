import java.util.ArrayList;

public class Store {

    // إنشاء المخزون كـ ArrayList من العناصر
    private ArrayList<Item> inventory;

    // Constructor لت initialization المخزون
    public Store() {
        inventory = new ArrayList<>();
    }

    // إضافة عنصر إلى المخزون
    public void addItem(Item item) {
        inventory.add(item);
        System.out.println(item.getTitle() + " has been added to the inventory.");
    }

    // إزالة عنصر من المخزون حسب العنوان
    public void removeItem(String title) {
        for (Item item : inventory) {
            if (item.getTitle().equalsIgnoreCase(title)) {
                inventory.remove(item);
                System.out.println(title + " has been removed from the inventory.");
                return;
            }
        }
        System.out.println("Item not found in inventory.");
    }

    // عرض المخزون
    public void displayInventory() {
        if (inventory.isEmpty()) {
            System.out.println("The inventory is empty.");
        } else {
            System.out.println("Inventory:");
            for (Item item : inventory) {
                System.out.println(item);
            }
        }
    }
}